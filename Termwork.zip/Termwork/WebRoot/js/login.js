$(document).ready(function() {
	$("#view").css({
		'margin-top':'-250px',
		'opacity':'1'
	});
});